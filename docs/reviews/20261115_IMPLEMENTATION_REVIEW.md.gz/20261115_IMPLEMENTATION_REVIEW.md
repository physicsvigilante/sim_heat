# **SIM_HEAT — Independent Implementation Review**

PR #3 · Commit `250779ec1e8ff5c6aa81d79b440e410436b65573` · 15 November 2026

## **1. Review scope and evidence**

This review follows `REVIEW_START_HERE.md` and is restricted to the H1 offline implementation candidate. It does not reopen H0 architecture or treat successful synthetic verification as proof of OpenModelica execution.

### **Independently verified**

- **Revision identity:** Reconstructed the Git tree from the packet's 61 tracked repository files. The calculated SHA-1 is `ee8cf4be7793604bfce7ac5a17521665294cf221`, matching the declared target tree.
- **Packet integrity:** Verified the sizes and SHA-256 hashes of all 74 files covered by the packet manifest, including Git blob identities for the tracked files.
- **Source fidelity:** Rendered and visually examined pages 2, 9 and 10 of `01_heat.pdf`, covering Illustrations 123, 134 and 135.
- **Code inspection:** Examined the authoring parser, topology, study validation, numerical reference, decoder, verification checker, CLI, Modelica spike, seven reference specifications, test suites and retained evidence.
- **Offline reproduction:** Reproduced the existing 86-test suite in an isolated copy using installed dependencies.

&#x20;86/86 tests passed

Independent rerun of author-written tests

The executed command was:

```
python -B -m unittest discover -s h1/tests -v
```

Environment: Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, Linux x86-64. Test runtime was approximately 1.1 seconds.

The retained development logs also record earlier failures followed by corrections, ending in the author's 86-test passing run. Those historical failures were preserved.

**Execution limitations:** No OpenModelica invocation, Modelica compilation, native simulation, dependency installation, tracked-file modification, reserved-challenge selection, commit or merge was performed. The repository snapshot contained no `.git` directory; revision identity was verified from its complete Git tree, not a local checkout history.

Passing the existing tests verifies their behavior in this environment. It does not make the fixtures independently authored or prove numerical correctness outside their tested cases.

## **2. Findings**

My overall assessment is **PASS WITH CONDITIONS**. The implementation is substantially stronger than the earlier spike, and I did not identify a fundamental error in the H1 component architecture or the principal thermal balance equations.

There is one numerical-policy inconsistency I recommend correcting before freeze, one reference-provenance correction, and several evidence obligations that must remain open until their proper gates.

### **Findings requiring action**

| ID / severity                               | Finding, exact location and smallest correction                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Gate                                                 |
| ------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| **R1 — Medium, implementation defect**      | **Timestamp tolerance is not coupled to trajectory sensitivity.** `h1/policy.py:38–55` permits shifted timestamps, but `h1/verification.py:120–132, 157–169` compares their values against the unshifted reference grid. A valid physical trajectory can therefore fail because of an otherwise permitted timestamp discrepancy. Add a reference-derived, predeclared sensitivity bound or tighten matching for affected cases; add a regression.                                                                                                                            | Offline acceptance/freeze                            |
| **R2 — Low, evidence defect**               | **S1 reference provenance is incorrectly worded.** `h1/reference_cases/S1.json:41` says that all numbers other than the calorie convention are illustrative. Illustration 123 actually supplies its lengths, diameter, conductivities and boundary temperatures. Correct the note prospectively, regenerate affected seals and preserve the historical artifacts.                                                                                                                                                                                                            | Offline acceptance/freeze                            |
| **R3 — High, numerical evidence gap**       | **The 100× reference-accuracy requirement is not independently established by the retained algorithm comparison.** `h1/reference.py:305–351`, especially `:326–339`, checks agreement between two calculations sharing the same matrix and floating-point inputs. Their agreement is not a bound on common-mode errors. Retain independent high-precision/closed-form checks and explicit error budgets for assessed quantities; extend that procedure to the eventual unfamiliar composition.                                                                               | Native numerical acceptance                          |
| **R4 — Medium, evidence-control gap**       | **The verifier trusts an externally supplied seal without enforcing a complete frozen-checker identity.** `h1/reference.py:347–351` records the reference implementation hash and dependency versions. `h1/verification.py:45–69` authenticates bundle consistency against the supplied seal, but does not separately bind the executing verifier/decoder version to an approved freeze manifest. Add that external manifest and require its identity at the controlled qualification gate. This is not a demonstrated cryptographic bypass of an independently pinned seal. | Native numerical acceptance and post-freeze transfer |
| **R5 — Medium, deferred native obligation** | **Real port-flow exports and arithmetic precision remain unqualified.** `h1/model.py:365–370` correctly requires both rod-port flows, and `h1/verification.py:125–132` checks them. But there is no native evidence that both requested variables are exported with the expected sign and precision. Require an actual export-schema and alias-semantics test; verify 64-ULP parameter allowances against real CSV output before adopting them.                                                                                                                              | Native execution/acceptance, not offline freeze      |
| **R6 — Low, test-coverage improvement**     | Tests at `h1/tests/test_offline.py:312–352` and `test_verification.py:187–199` cover important timestamp and CSV failures, but do not comprehensively exercise CRLF hash preservation, exact matching boundaries, harmless extra columns, or the R1 sensitivity case. Add focused regressions and document that extra CSV columns are ignored rather than interpreted as physical evidence.                                                                                                                                                                                  | Offline freeze for R1 regression; otherwise optional |

### **R1: Reproducible timestamp-policy counterexample**

This is a **false-rejection issue**, not evidence that an incorrect trajectory can obtain a physical PASS.

Consider an otherwise ordinary D1 arrangement with:

- Body capacity \\(C=10^{-8}\ \mathrm{J/K}\\).
- Rod conductance \\(G=0.2\ \mathrm{W/K}\\).
- Initial body temperature 293.15 K and reservoir temperature 353.15 K.
- `stopTime=1e-6`, `intervals=1000`.

All values satisfy the currently declared positive-parameter and analysis-domain restrictions.

The time constant is \\(\tau=C/G=5\times10^{-8}\\) s. The output spacing is \\(10^{-9}\\) s, and the matching allowance is approximately \\(10^{-10}\\) s.

At the first nonzero output time, shifting the timestamp by a permitted amount of approximately \\(10^{-10}\\) s changes the exact analytical body temperature by roughly **0.1175 K**. The sealed temperature comparison allowance would be approximately **0.00007 K**.

Thus, a physically correct sample at an allowed timestamp can exceed the value allowance by approximately 1,679 times.

The independent timestamp-matching helper accepts such a shift. This case was assessed using analytical arithmetic and the existing matching policy, not a Modelica execution.

**Smallest correction:** Introduce a reference-derived temporal-sensitivity preflight. Where the maximum effect of an allowed timestamp displacement exceeds a defined fraction of the value allowance, reduce the matching window or refuse that case before execution. Do not silently enlarge the physical trajectory tolerance or interpolate missing values.

This preserves the conservative F2 philosophy and general composability.

## **3. Independent mathematical assessment**

The core reference construction is sound for the inspected physical domain.

`h1/reference.py:162–239` builds a conductance Laplacian, eliminates algebraic junctions, handles constant-temperature boundaries, and evaluates transient states using an augmented affine matrix exponential. The spectral path uses a capacity-scaled symmetric operator and explicitly handles closed-network zero modes.

I found no incorrect sign in the steady, single-body, two-body, reversed-flow or isolated-body reference equations.

### **Additional high-precision check**

I independently evaluated the seven exposed scalar cases using 80-digit `mpmath` arithmetic, explicit physical formulas, and their intended output times. I compared these against the author-prepared reference bundles across the stored grids.

For each case, the quantity below is:

\\[ R=\max\frac{|\text{stored reference}-\text{high-precision value}|} {\text{comparison allowance}/100} \\]

| Case  | Largest observed \\(R\\) | Result          |
| ----- | ------------------------ | --------------- |
| S1    | 0.428                    | Below threshold |
| D1    | 0.625                    | Below threshold |
| D2    | 0.625                    | Below threshold |
| D2-K2 | 0.625                    | Below threshold |
| EQ    | 0.625                    | Below threshold |
| REV   | 0.625                    | Below threshold |
| ISO   | 0.000000207              | Below threshold |

The largest discrepancies in several cases concern the binary representation of the constant conductance, not the evolving temperatures. Independent flow-integral comparisons were also comfortably below their one-hundredth allowance.

**Interpretation:** This provides genuinely additional numerical support for the seven exposed analytic cases; it is not merely agreement between the two production reference algorithms.

It is still a high-precision numerical comparison, not a formal enclosure of every arithmetic error. In particular, a ratio of 0.625 leaves limited margin against the stringent 100× parameter-error threshold. The result should be retained with its formulas, precision, reference identities and dependency versions before claiming that requirement is conclusively discharged.

For an eventual unfamiliar composition, I recommend a bounded independently implemented selected-point evaluation, using high precision and explicit conditioning/residual checks. A universal proof for all admitted thermal networks is unnecessary for this gate.

## **4. Conservation, restrictions and negative tests**

The following implementation behavior is supported by source inspection and the reproduced suite.

| Area                    | Assessment                                                                                                                                                                                                                                   |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Restricted authoring    | The parser consumes the full permitted input, rejects unsupported syntax, enforces required component fields and typed parameter references, and applies conservative topology rules (`model.py:77–223, 236–333`).                           |
| Provenance and revision | Model/study hashes, constrained paths, parent identities and effective-property comparisons are checked. Shared parameters affecting a second rod are refused (`study.py:41–153`). A validated provenance link does not prove its note true. |
| Local normalization     | Temperature scales are local; rod-flow and body-energy scales are per output. A large disconnected network or another large branch does not directly enlarge a smaller output's reference-comparison allowance (`reference.py:307–329`).     |
| Rod checks              | Both port flows are mandatory. Rod conservation, orientation and Fourier-law residuals are checked. The second port is not synthesized from the first (`verification.py:125–132`).                                                           |
| Nodes and bodies        | Temperature equality, signed node balance, initialization, energy ownership, body-flow integration and connected-network energy balances are checked (`verification.py:133–169`).                                                            |
| Failure handling        | Failed numerical checks suppress diagnostic requested values. Empty request sets do not disable mandatory physics checks (`verification.py:174–205`).                                                                                        |
| Evidence labels         | Only `synthetic` and `unattested_output` are admitted; successful checks remain `diagnostic_only`, with `nativeQualified=false` and `nativeExecuted=false`.                                                                                  |
| CSV and time            | Required columns, finite values, row completeness, ordered samples and grid association are checked. Exact matching duplicates may be collapsed; conflicting duplicates refuse (`decoder.py:13–45`).                                         |

A large branch can make a **summed node-balance allowance** numerically large, because that balance legitimately includes all its incident terms. Crucially, the smaller branch retains its own independent comparison, so such dilution does not by itself produce an overall false PASS.

The deliberate fault-injection tests also exercise meaningful failures. In particular, `test_verification.py:160–166` demonstrates errors that cancel in the network total yet fail local body checks. The negative-flow and missing-second-port tests reach the intended physical checks.

The current implementation therefore has a credible **generic checker**, not seven apparatus-specific production paths.

## **5. F1–F6 disposition**

| Finding                                 | Current disposition                                                                                                                                                 | Remaining gate                                            |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| **F1 — Local allowances**               | **Partially addressed.** Correct local construction and meaningful fault detection demonstrated offline. Reference-error budgets and native precision need closure. | Native numerical acceptance                               |
| **F2 — Timestamp matching**             | **Partially addressed.** Spacing and ULP rules implemented; R1 requires correction for consistency with value comparisons.                                          | Offline freeze                                            |
| **F3 — Restricted implementation**      | **Supported for offline scope.** Parser, study descriptors, revisions, requests and synthetic decoder exist and pass tests. Native runner still absent.             | Native implementation and later reuse                     |
| **F4 — Independent physical checks**    | **Partially addressed.** Separate inputs, signed flows, conservation and closed-form cases supported. No native physical measurements.                              | Native numerical acceptance                               |
| **F5 — Native environment and exports** | **Intentionally deferred.** No compiler/MSL qualification, actual CSV/alias evidence or controlled execution.                                                       | Native execution authorization                            |
| **F6 — Analysis/refusal domain**        | **Supported offline, with R1 caveat.** Finite bounds, grid sizes and post-freeze C1 exception documented. Native scenario settings remain unapproved.               | Offline freeze for R1; native plan for execution settings |

## **6. Separate gate verdicts**

**Offline implementation acceptance**

PASS WITH CONDITIONS

The candidate is technically credible and all existing offline tests pass. I recommend withholding its final freeze until R1 is resolved, the S1 provenance note is corrected, and the resulting regression/evidence identities are recorded without rewriting historical logs.

**Readiness to prepare a controlled native-execution plan**

PASS WITH CONDITIONS

A bounded, desk-only plan can be prepared around this implementation, subject to the offline corrections. Formal advancement to the native execution gate should wait for offline freeze and an independently reviewed plan specifying the exact OpenModelica/MSL pairing, model compilation and initialization checks, real CSV/alias exports, output precision, reference seals, run containment, numerical companions and failure preservation.

Neither verdict authorizes OpenModelica execution, installation, native qualification, C1 selection, publication or merge.

## **7. Independence and final recommendation**

This is **GPT-6 reviewing the attached snapshot**. I previously reviewed SIM_HEAT PR #1 and PR #2 and identified the original F1–F6 conditions. Consequently, this is not a blind first exposure to the architecture or numerical concerns. I did not author or edit this PR #3 implementation during the present review. The new source inspection, full-grid high-precision comparison and offline test reproduction described above were performed in this review context.

There remains no independently observed native simulation, no selected reserved challenge, and no demonstrated post-freeze unfamiliar composition. Those claims should remain separate from this acceptance decision.

My recommendation is to **correct R1 and R2 narrowly, retain the additional reference-accuracy evidence, and then freeze the offline candidate for controlled native-plan preparation**. No architecture redesign is warranted. The main outstanding work is qualification and evidence control, rather than expanding the physical component library.&#x20;